import React, { useEffect, useRef } from "react";
import type { Direction, Ghost, GhostType, Position } from "../types/gameTypes";
import { canvasWrapperStyle, legendRowStyle, primaryBtnStyle } from "../styles/gameStyles";

interface GameCanvasProps {
  grid: number[][];
  pacman: Position;
  direction: Direction;
  ghosts: Ghost[];
  status: "PLAYING" | "GAME_OVER" | "VICTORY";
  onReset: () => void;
}

const GHOST_RING_COLORS: Record<GhostType, string> = {
  chaser: "#ff4d4f",
  ambusher: "#ff85c0",
  sprinter: "#fa8c16",
  teleporter: "#722ed1",
};

const GHOST_IMAGE_KEYS: Record<GhostType, string> = {
  chaser: "ghost1",
  ambusher: "ghost2",
  sprinter: "ghost3",
  teleporter: "ghost1",
};

export const GameCanvas: React.FC<GameCanvasProps> = ({
  grid,
  pacman,
  ghosts,
  status,
  onReset,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const spritesRef = useRef<Record<string, HTMLImageElement>>({});

  useEffect(() => {
    const sources: Record<string, string> = {
      player: "/sprites/player.png",
      ghost1: "/sprites/ghost-1.png",
      ghost2: "/sprites/ghost-2.png",
      ghost3: "/sprites/ghost-3.png",
    };

    Object.entries(sources).forEach(([key, src]) => {
      const img = new Image();
      img.src = src;
      spritesRef.current[key] = img;
    });
  }, []);

  const drawCircularAvatar = (
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement | undefined,
    centerX: number,
    centerY: number,
    radius: number,
    ringColor: string
  ) => {
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    if (img?.complete && img.naturalWidth > 0) {
      ctx.drawImage(img, centerX - radius, centerY - radius, radius * 2, radius * 2);
    } else {
      ctx.fillStyle = ringColor;
      ctx.fillRect(centerX - radius, centerY - radius, radius * 2, radius * 2);
    }
    ctx.restore();

    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.strokeStyle = ringColor;
    ctx.lineWidth = 2;
    ctx.stroke();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const size = 456;
    const tile = size / grid.length;
    ctx.clearRect(0, 0, size, size);

    // 1. Draw Maze Walls & Dots
    grid.forEach((row, y) => {
      row.forEach((cell, x) => {
        if (cell === 1) {
          ctx.fillStyle = "#111111";
          ctx.fillRect(x * tile + 1, y * tile + 1, tile - 2, tile - 2);
        } else if (cell === 0) {
          ctx.fillStyle = "#bbbbbb";
          ctx.beginPath();
          ctx.arc(x * tile + tile / 2, y * tile + tile / 2, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      });
    });

    // 2. Draw Player Avatar
    drawCircularAvatar(
      ctx,
      spritesRef.current.player,
      pacman.x * tile + tile / 2,
      pacman.y * tile + tile / 2,
      tile / 2 - 1,
      "#f5b800"
    );

    // 3. Draw Ghost Avatars
    ghosts.forEach((g) => {
      const imgKey = GHOST_IMAGE_KEYS[g.type];
      drawCircularAvatar(
        ctx,
        spritesRef.current[imgKey],
        g.pos.x * tile + tile / 2,
        g.pos.y * tile + tile / 2,
        tile / 2 - 1,
        GHOST_RING_COLORS[g.type]
      );
    });
  }, [grid, pacman, ghosts]);

  return (
    <div style={{ width: "100%" }}>
      <div style={canvasWrapperStyle}>
        <canvas
          ref={canvasRef}
          width={456}
          height={456}
          style={{ width: "100%", height: "100%", display: "block" }}
        />
        {status !== "PLAYING" && (
          <div style={overlayStyle}>
            <h3 style={{ margin: "0 0 0.75rem 0" }}>
              {status === "VICTORY" ? "All 10 Levels Cleared!" : "Game Over"}
            </h3>
            <button style={primaryBtnStyle} onClick={onReset}>
              Play Again
            </button>
          </div>
        )}
      </div>
      <div style={legendRowStyle}>
        <span>🔴 Chaser</span>
        <span>🩷 Ambusher</span>
        <span>🟠 Sprinter</span>
        <span>🟣 Teleporter</span>
      </div>
    </div>
  );
};

const overlayStyle: React.CSSProperties = {
  position: "absolute",
  inset: 0,
  backgroundColor: "rgba(255, 255, 255, 0.92)",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
};